import { readFile } from 'node:fs/promises';
import {validate} from './assets/engine.js';
const bank=validate(JSON.parse(await readFile(new URL('./data/content.json',import.meta.url),'utf8')));
console.log(`Valid content: ${bank.sections.length} sections, ${bank.sections.reduce((n,s)=>n+s.levels.length,0)} levels.`);
