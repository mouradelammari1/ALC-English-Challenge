# Content authoring

`data/content.json` is the single published content bank. Editing it never requires rebuilding application code. Save a teacher draft locally, export and commit it to share it.

## Structure

The root has `version: 1` and three `sections`. A section contains id, title, optional tagline and description, and levels. Levels contain id, title, optional group, and units. Preserve all original section and level IDs. Units contain id, title, lessons. Lessons contain id, title, quizzes. Use an empty array for unpublished content.

Each quiz contains:

| Field | Value |
| --- | --- |
| id | Globally unique lowercase letters, numbers, hyphens |
| title | Teacher-provided title |
| category | vocabulary, grammar, review, challenge, or remedial |
| questions | One or more question objects |

Each question has a unique id, a title, prompt, explanation, and type:

- `choice`: `options` is an array of at least two non-empty strings. `answer` is the zero-based index of the correct option.
- `text`: `answers` is a non-empty array of accepted strings. Matching ignores leading/trailing whitespace and case, but preserves punctuation and internal spacing.

The following is an authoring template, not course content. Replace every placeholder and supply a verified answer before saving. Do not insert templates into the student bank.

```json
{
  "id": "replace-quiz-id",
  "title": "REPLACE WITH TEACHER TITLE",
  "category": "vocabulary",
  "questions": [{
    "id": "replace-question-id",
    "title": "REPLACE WITH QUESTION TITLE",
    "type": "choice",
    "prompt": "REPLACE WITH APPROVED PROMPT",
    "options": ["REPLACE OPTION", "REPLACE OPTION"],
    "answer": 0,
    "explanation": "REPLACE WITH VERIFIED EXPLANATION"
  }]
}
```

For typed questions use `"type": "text", "answers": ["TEACHER-APPROVED ANSWER"]` instead of options and answer.

Unit challenges belong in a teacher-named review/challenge lesson inside the relevant unit, preserving the same navigation hierarchy. Remedial activities use category `remedial`; they are teacher-assigned rather than automatically generated.

## Updating safely

1. Export a backup before editing.
2. Add your approved curriculum, keeping IDs stable so existing bookmarks and progress still match.
3. Save a browser draft; check navigation and answer feedback.
4. Export, replace `data/content.json`, and run `npm test` and `npm run validate`.
5. Commit to the separate ALC repository. The Pages workflow deploys the update.

Delete objects to remove content. Rename titles to edit displayed names. Changing a quiz ID intentionally creates a new progress identity. Existing browser drafts can override published content: use Restore published content to view the latest deployed bank. No HTML or rich-text execution is supported; teacher text is rendered as plain text.
