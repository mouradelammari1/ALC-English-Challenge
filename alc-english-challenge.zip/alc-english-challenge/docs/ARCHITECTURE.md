# Architecture

Buildless HTML/CSS/ES modules. No framework, service, API key, or paid dependency. Google Fonts enhance typography; system sans-serif fallback remains usable when offline or blocked. Serve files over HTTP.

- `index.html`: semantic shell and teacher workspace entry.
- `assets/style.css`: responsive themes and decorative CSS artwork.
- `assets/app.js`: hash routing, safe text rendering, quiz runner, browser persistence and teacher editor.
- `assets/engine.js`: shared bank validation, answer grading, score calculation.
- `data/content.json`: editable curriculum source.
- `tests/engine.test.js`: isolated technical fixtures; not deployed.
- `.github/workflows/pages.yml`: checks and static Pages publication.

Navigation: `#/section/level/unit/lesson/quiz`. Missing or removed content produces a recovery page. Empty levels never fabricate unit counts or course completion.

Storage keys use `alc-english-challenge:v1:`. `draft` stores the locally previewed bank. `progress` stores quiz title, last and best scores, attempts, and replay route. Progress is saved only after quiz completion; no student identities are collected. Correct answers are locked after checking and all questions count equally. Percentage is rounded to the nearest integer. Replay resets the current attempt and preserves the best completed result.

The editor does not publish directly. GitHub repository permissions control changes to the public content bank. Add authenticated editing only in a later stage with an explicitly designed identity and publishing system.

Validation checks hierarchy arrays, exact required level sets, globally unique IDs, category values, supported question types, valid answer indexes, and explanations. Import has a 5 MB size limit. Teacher-entered text is escaped before display.

## Verification limits

Automated Node tests cover structure, validation, scoring, and answer matching. Browser layout and end-to-end flows need a browser QA pass before broad student rollout. The managed environment did not expose a supported browser-control tool for this delivery.
