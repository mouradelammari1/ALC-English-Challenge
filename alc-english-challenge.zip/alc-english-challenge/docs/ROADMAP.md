# Staged development

1. **Foundation (complete):** independent project, 30 levels, responsive age-specific spaces, reusable quiz engine, local progress, teacher authoring tools, validation, Pages workflow and documentation.
2. **Curriculum integration (awaiting teacher materials):** map supplied textbooks and learning objectives to units and lessons; import only approved content. Confirm answer variants, explanations and remedial pathways.
3. **Classroom pilot:** test phones, keyboard/screen reader flows and teacher import/export with real approved material. Refine feedback and visual treatments with students and teachers.
4. **Publishing:** create the separate GitHub repository and enable Pages. This can happen before or after curriculum integration.
5. **Optional expansion:** richer guided quiz forms, media questions, accessibility refinements, teacher authentication and shared progress only after requirements are agreed.

Do not generate substitute lessons or assume textbook unit counts.
