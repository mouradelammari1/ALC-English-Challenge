# ALC English Challenge

An independent static learning application for American Language Center students. It does not share files, storage keys, deployment settings, or repository history with CPGE English Challenge.

## Stage 1 — foundation

- Children 1, 2, 4, 5, 6 (Children 3 intentionally absent).
- Juniors 1–6 and YA.
- Adults: Beginning 1–6, Intermediate 1–6, Advanced 1–6.
- Hierarchy: section → level → unit → lesson → quiz.
- Vocabulary, grammar, lesson reviews, unit challenges, remedial practice.
- Age-specific color and card treatments, mobile layouts, keyboard controls, feedback and progress.
- Teacher workspace with unit/lesson forms, full JSON editing, validation, import/export, browser draft preview and published-content restore.

No lessons, units, learning objectives, or quizzes have been invented. All 30 levels start empty. Technical test fixtures are outside the published files.

## Run locally

Requires Python 3 to serve files, Node 18+ for checks. No dependency installation or build required.

```sh
cd alc-english-challenge
python3 -m http.server 8000
# Open http://localhost:8000
npm test
npm run validate
```

Serve over HTTP; opening index.html as a file will not load the JSON bank reliably.

## Publish free on GitHub Pages in a NEW repository

1. Create a new repository named `alc-english-challenge` in your own GitHub account. Do not select the CPGE repository. A public repository supports free GitHub Pages.
2. Push this directory's separate Git history to that new repository:

```sh
git remote add origin https://github.com/YOUR-USERNAME/alc-english-challenge.git
git push -u origin main
```

3. In the new repository, open **Settings → Pages → Build and deployment → Source → GitHub Actions**.
4. Run the **Validate and publish GitHub Pages** workflow, or push to main. It validates content and tests before publishing only index.html, assets, and data.
5. The deployment returns `https://YOUR-USERNAME.github.io/alc-english-challenge/`.

All asset paths are relative and routes use hashes, so nested navigation works on a repository subpath without server rewrites. No GitHub repository has been created and no live deployment has been performed as part of this foundation delivery.

## Teacher editing

Open **Teacher workspace**. Add units/lessons using the form. Add/edit/remove quizzes or questions in the JSON editor. Save a browser draft to preview, then export `content.json`. Replace the repository's `data/content.json` with the export and commit to publish. Import/export also provides backups. Unsaved editor changes are not automatically preserved when closing and reopening the toolbar.

The toolbar is deliberately a local authoring tool visible to everyone. A student can change only their own browser draft, not published content. There is no teacher authentication, server-side persistence, shared student tracking, or direct repository write access. Published quiz answers are downloadable, so this is a practice application, not a secure examination system. Progress belongs to the browser/device, without accounts. Browser storage may be cleared by the browser; export drafts for safekeeping.

Read [Content authoring](docs/CONTENT.md), [Architecture](docs/ARCHITECTURE.md), [Roadmap](docs/ROADMAP.md), and [History](CHANGELOG.md).
