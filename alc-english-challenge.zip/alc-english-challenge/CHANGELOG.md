# Project history

## 0.1.0 — 2026-11-15

- Created ALC English Challenge as an independent static project.
- Established exact Children, Juniors/YA and Adults level structure.
- Added section → level → unit → lesson → quiz navigation and honest empty states.
- Added reusable choice/text questions, immediate feedback, explanations, scoring, review and replay.
- Added device-local progress and independent storage keys.
- Added teacher browser drafts, unit/lesson creation, JSON editing, validated import/export and published-content restore.
- Added responsive learning-space themes, accessibility foundations and CSS illustrations.
- Prepared a separate Git history, documentation, staged roadmap and GitHub Pages deployment workflow.
- Left all course content empty pending teacher materials. No existing CPGE files were accessed or changed.
