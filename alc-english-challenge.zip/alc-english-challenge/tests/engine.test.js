import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {validate,isCorrect,score} from '../assets/engine.js';
const baseline=()=>JSON.parse(readFileSync(new URL('../data/content.json',import.meta.url)));
// Technical fixtures only. Never loaded by the student application.
const choice={id:'fixture-question',title:'Technical fixture',type:'choice',prompt:'Fixture prompt',options:['A','B'],answer:1,explanation:'Fixture explanation'};
const populated=()=>{const b=baseline();b.sections[0].levels[0].units=[{id:'fixture-unit',title:'Fixture',lessons:[{id:'fixture-lesson',title:'Fixture',quizzes:[{id:'fixture-quiz',title:'Fixture',category:'vocabulary',questions:[structuredClone(choice)]}]}]}];return b;};
test('exact required structure, no invented curriculum',()=>{const b=validate(baseline());assert.deepEqual(b.sections.map(s=>s.levels.length),[5,7,18]);assert.ok(b.sections.every(s=>s.levels.every(l=>l.units.length===0)));});
test('valid reusable quiz bank',()=>assert.ok(validate(populated())));
test('rejects removed required levels and duplicate IDs',()=>{const b=baseline();b.sections[0].levels.pop();assert.throws(()=>validate(b));const c=populated();c.sections[0].levels[0].units[0].id='children';assert.throws(()=>validate(c));});
test('rejects invalid answer indexes and missing explanations',()=>{const b=populated(),q=b.sections[0].levels[0].units[0].lessons[0].quizzes[0].questions[0];q.answer=2;assert.throws(()=>validate(b));q.answer=1;q.explanation='';assert.throws(()=>validate(b));});
test('choice and normalized typed answer grading',()=>{assert.equal(isCorrect(choice,1),true);assert.equal(isCorrect(choice,0),false);const q={type:'text',answers:['Accepted','Alternative']};assert.equal(isCorrect(q,'  ACCEPTED '),true);assert.equal(isCorrect(q,'alternative'),true);assert.equal(isCorrect(q,'wrong'),false);});
test('scoring handles empty, mixed and perfect attempts',()=>{assert.equal(score([]),0);assert.equal(score([true,false,true]),67);assert.equal(score([true,true]),100);});
test('text banks validate accepted answers and categories',()=>{const b=populated(),quiz=b.sections[0].levels[0].units[0].lessons[0].quizzes[0];quiz.questions[0]={id:'text-fixture',title:'Fixture',type:'text',prompt:'Fixture',answers:['A'],explanation:'Fixture'};assert.ok(validate(b));quiz.questions[0].answers=[];assert.throws(()=>validate(b));quiz.questions[0].answers=['A'];quiz.category='unknown';assert.throws(()=>validate(b));});
